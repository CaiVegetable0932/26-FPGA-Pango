#ifndef __ATD5984_H
#define __ATD5984_H

#include "sys.h"

void ATD5984_Init(void);
void STEP12_PWM_Init(u16 arr, u16 psc);



#endif
