Offline PG2L100H toolchain diagnostic only. No hardware programming performed.
This is not the planned 1080p video system. Strict SDF simulation has a vendor-model warning.
Read fpga/reports/latest.md and fpga/README.md. Installed PDS and ModelSim are required to rebuild.
