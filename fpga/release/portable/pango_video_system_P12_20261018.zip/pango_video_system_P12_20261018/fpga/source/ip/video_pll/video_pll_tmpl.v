// Created by IP Generator (Version 2022.2-SP6.4 build 146967)
// Instantiation Template
//
// Insert the following codes into your Verilog file.
//   * Change the_instance_name to your own instance name.
//   * Change the signal names in the port associations


video_pll the_instance_name (
  .clkin1(clkin1),      // input
  .clkout1(clkout1),    // output
  .lock(lock)           // output
);
